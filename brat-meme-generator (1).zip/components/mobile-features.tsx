"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Share2, TrendingUp, Smartphone, Zap, Users } from "lucide-react"

export function MobileFeatures() {
  const [isMobile, setIsMobile] = useState(false)
  const [installPrompt, setInstallPrompt] = useState<any>(null)
  const [stats, setStats] = useState({
    memesCreated: 0,
    dailyUsers: 0,
    trending: 0,
  })

  useEffect(() => {
    setIsMobile(window.innerWidth < 768)

    // Simulate real-time stats
    const updateStats = () => {
      setStats({
        memesCreated: Math.floor(Math.random() * 1000) + 5000,
        dailyUsers: Math.floor(Math.random() * 500) + 2000,
        trending: Math.floor(Math.random() * 50) + 100,
      })
    }

    updateStats()
    const interval = setInterval(updateStats, 30000) // Update every 30 seconds

    const handleResize = () => {
      setIsMobile(window.innerWidth < 768)
    }

    const handleInstallPrompt = (e: any) => {
      e.preventDefault()
      setInstallPrompt(e)
    }

    window.addEventListener("resize", handleResize)
    window.addEventListener("beforeinstallprompt", handleInstallPrompt)

    return () => {
      window.removeEventListener("resize", handleResize)
      window.removeEventListener("beforeinstallprompt", handleInstallPrompt)
      clearInterval(interval)
    }
  }, [])

  const handleInstallApp = async () => {
    if (installPrompt) {
      installPrompt.prompt()
      const result = await installPrompt.userChoice
      if (result.outcome === "accepted") {
        setInstallPrompt(null)
      }
    }
  }

  const handleNativeShare = async (memeData: any) => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: "Check out my Brat meme!",
          text: "Made with AI Brat Generator",
          url: window.location.href,
        })
      } catch (error) {
        console.log("Error sharing:", error)
      }
    }
  }

  if (!isMobile) return null

  return (
    <Card className="gradient-card mb-6">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Smartphone className="h-5 w-5" />
          Mobile Features
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Live Stats */}
        <div className="grid grid-cols-3 gap-4 mb-4">
          <div className="text-center">
            <div className="flex items-center justify-center mb-1">
              <Zap className="h-4 w-4 text-primary mr-1" />
              <span className="text-lg font-bold">{stats.memesCreated.toLocaleString()}</span>
            </div>
            <p className="text-xs text-muted-foreground">Memes Created</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center mb-1">
              <Users className="h-4 w-4 text-primary mr-1" />
              <span className="text-lg font-bold">{stats.dailyUsers.toLocaleString()}</span>
            </div>
            <p className="text-xs text-muted-foreground">Daily Users</p>
          </div>
          <div className="text-center">
            <div className="flex items-center justify-center mb-1">
              <TrendingUp className="h-4 w-4 text-primary mr-1" />
              <span className="text-lg font-bold">{stats.trending}</span>
            </div>
            <p className="text-xs text-muted-foreground">Trending Now</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4">
          {installPrompt && (
            <Button onClick={handleInstallApp} className="gradient-bg text-white border-0 hover:opacity-90">
              Install App
            </Button>
          )}

          <Button onClick={() => handleNativeShare({})} variant="outline" className="flex items-center gap-2">
            <Share2 className="h-4 w-4" />
            Share
          </Button>

          <div className="col-span-2 space-y-2 text-sm text-muted-foreground">
            <p>
              💡 <strong>Touch & Drag:</strong> Move text anywhere on your meme!
            </p>
            <p>
              📱 <strong>Quick Access:</strong> Add to home screen for instant meme creation
            </p>
            <p>
              🚀 <strong>Offline Mode:</strong> Create memes even without internet
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
