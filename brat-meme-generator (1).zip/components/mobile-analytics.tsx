"use client"

import { useEffect } from "react"

declare global {
  interface Window {
    gtag?: (...args: any[]) => void
  }
}

export function MobileAnalytics() {
  useEffect(() => {
    // Track mobile-specific events
    const trackMobileEvents = () => {
      const isMobile = window.innerWidth < 768
      const isTouch = "ontouchstart" in window
      const userAgent = navigator.userAgent

      // Track device info
      if (window.gtag) {
        window.gtag("event", "device_info", {
          event_category: "mobile",
          is_mobile: isMobile,
          is_touch: isTouch,
          screen_width: window.innerWidth,
          screen_height: window.innerHeight,
          user_agent: userAgent,
        })
      }

      // Track PWA usage
      if (window.matchMedia("(display-mode: standalone)").matches) {
        if (window.gtag) {
          window.gtag("event", "pwa_usage", {
            event_category: "mobile",
            event_label: "standalone_mode",
          })
        }
      }

      // Track orientation changes
      const handleOrientationChange = () => {
        if (window.gtag) {
          window.gtag("event", "orientation_change", {
            event_category: "mobile",
            orientation: window.innerWidth > window.innerHeight ? "landscape" : "portrait",
          })
        }
      }

      window.addEventListener("orientationchange", handleOrientationChange)

      return () => {
        window.removeEventListener("orientationchange", handleOrientationChange)
      }
    }

    // Track touch interactions
    const trackTouchInteractions = () => {
      let touchCount = 0

      const handleTouch = () => {
        touchCount++
        if (touchCount % 10 === 0 && window.gtag) {
          window.gtag("event", "touch_interactions", {
            event_category: "mobile",
            value: touchCount,
          })
        }
      }

      document.addEventListener("touchstart", handleTouch, { passive: true })

      return () => {
        document.removeEventListener("touchstart", handleTouch)
      }
    }

    const cleanup1 = trackMobileEvents()
    const cleanup2 = trackTouchInteractions()

    return () => {
      cleanup1?.()
      cleanup2?.()
    }
  }, [])

  return null
}
