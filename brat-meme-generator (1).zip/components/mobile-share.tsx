"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Share2, Copy, Check, Instagram, Twitter, MessageCircle } from "lucide-react"

interface MobileShareProps {
  memeUrl?: string
  memeTitle?: string
}

export function MobileShare({ memeUrl, memeTitle = "Check out my Brat meme!" }: MobileShareProps) {
  const [copied, setCopied] = useState(false)

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: memeTitle,
          text: "Made with AI Brat Generator",
          url: memeUrl || window.location.href,
        })
      } catch (error) {
        console.log("Error sharing:", error)
      }
    }
  }

  const handleCopyLink = async () => {
    try {
      await navigator.clipboard.writeText(memeUrl || window.location.href)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (error) {
      console.log("Error copying:", error)
    }
  }

  const shareToSocial = (platform: string) => {
    const text = encodeURIComponent(memeTitle)
    const url = encodeURIComponent(memeUrl || window.location.href)

    const urls = {
      instagram: `https://www.instagram.com/`,
      twitter: `https://twitter.com/intent/tweet?text=${text}&url=${url}`,
      whatsapp: `https://wa.me/?text=${text}%20${url}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${url}`,
    }

    window.open(urls[platform as keyof typeof urls], "_blank", "width=600,height=400")
  }

  return (
    <Card className="gradient-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Share2 className="h-5 w-5" />
          Share Your Meme
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-3">
          {navigator.share && (
            <Button onClick={handleNativeShare} className="gradient-bg text-white border-0 hover:opacity-90">
              <Share2 className="h-4 w-4 mr-2" />
              Share
            </Button>
          )}

          <Button onClick={handleCopyLink} variant="outline" className="flex items-center gap-2 bg-transparent">
            {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
            {copied ? "Copied!" : "Copy Link"}
          </Button>

          <Button onClick={() => shareToSocial("instagram")} variant="outline" className="flex items-center gap-2">
            <Instagram className="h-4 w-4" />
            Instagram
          </Button>

          <Button onClick={() => shareToSocial("twitter")} variant="outline" className="flex items-center gap-2">
            <Twitter className="h-4 w-4" />
            Twitter
          </Button>

          <Button onClick={() => shareToSocial("whatsapp")} variant="outline" className="flex items-center gap-2">
            <MessageCircle className="h-4 w-4" />
            WhatsApp
          </Button>

          <Button onClick={() => shareToSocial("facebook")} variant="outline" className="flex items-center gap-2">
            <Share2 className="h-4 w-4" />
            Facebook
          </Button>
        </div>

        <div className="mt-4 p-3 bg-muted rounded-lg">
          <p className="text-sm text-muted-foreground">
            💡 <strong>Pro Tip:</strong> Save to your camera roll and share directly to Stories!
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
